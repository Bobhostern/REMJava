package mathClass.colorClass;

/**
 *
 * @author onigiri
 */
public enum BasicColor {
    RED,
    BLUE,
    GREEN
}
